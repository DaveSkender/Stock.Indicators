---
description: Drive iterative clarification of ambiguous or incomplete specification content before planning
scripts:
	sh: scripts/bash/create-new-feature.sh --json
	ps: scripts/powershell/create-new-feature.ps1 -Json
---

# /clarify Command Template

## Purpose

Request focused clarification on ambiguous, incomplete, or conflicting parts of an in-progress specification, plan, or task list.

## When to Use

- Unclear parameter definitions
- Missing mathematical formula detail
- Conflicting acceptance criteria
- Unspecified edge cases or warmup logic
- Performance target ambiguity

## Expected Input

- Reference context (spec/task/plan section or quote)
- Specific questions (bullet list form)
- Optional proposed assumptions for confirmation

## Output Structure

1. Restated context (concise)
2. Clarification questions (enumerated)
3. Suggested assumptions (if user silent)
4. Blocking vs non-blocking issues

## Style Guidance

- Ask for the minimum confirmations needed to proceed
- Group related questions
- Offer default assumptions to accelerate progress

## Example Invocation

```text
/clarify In spec 002 baseline format: Are timestamps stored as UTC ticks? Are trailing NaN columns trimmed? What hash algorithm is canonical? Suggest defaults if not defined.
```

## Response Tone

Collaborative, precise, bias toward forward progress.

---
Last updated: October 2, 2025
