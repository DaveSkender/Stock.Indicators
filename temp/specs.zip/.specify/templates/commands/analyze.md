---
description: Perform cross-artifact consistency and quality analysis across spec.md, plan.md, tasks.md (read-only)
scripts:
	sh: scripts/bash/check-prerequisites.sh --json --require-tasks --include-tasks
	ps: scripts/powershell/check-prerequisites.ps1 -Json -RequireTasks -IncludeTasks
---

# /analyze Command Template

## Purpose

Analyze existing code or implementation for a specific indicator or subsystem and produce actionable review notes (performance, accuracy, validation, style, documentation gaps).

## Expected Inputs

- Target scope (file(s), indicator name, or subsystem)
- Focus areas (performance, accuracy, validation, streaming readiness, documentation)

## Output Structure

1. Summary
2. Strengths
3. Findings (categorized)
4. Recommendations (ordered, actionable)
5. Risk assessment (if applicable)

## Categorization of Findings

- Performance: allocations, complexity, redundant calculations
- Accuracy: formula deviations, numerical stability, precision misuse
- Validation: missing guards, edge case handling
- API & Ergonomics: naming, parameter order, consistency
- Streaming Readiness: state handling, buffer reuse, incremental update design
- Documentation: missing XML docs, unclear summaries, missing parameter remarks

## Review Checklist

- Correct lookback/warmup periods
- Proper null handling and NaN propagation rules
- Avoids unnecessary LINQ in hot loops
- Uses `double` internally unless price-sensitive output requires `decimal`
- Consistent error messages (exception types + message format)
- Result model follows record + `IReusable` pattern
- Streaming compatibility (if applicable) or explicit note why not

## Example Invocation

```text
/analyze Review SMA implementation for performance and validation completeness
```

## Response Tone

Objective, concise, actionable. Avoid restating obvious code.

---
Last updated: October 2, 2025
