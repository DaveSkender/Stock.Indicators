#!/usr/bin/env bash
set -e
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
FEATURE_SPEC=$(ls -1t "$REPO_ROOT/specs"/*/spec.md 2>/dev/null | head -n1)
[[ -z "$FEATURE_SPEC" ]] && { echo "Error: no spec.md found" >&2; exit 1; }
FEATURE_DIR=$(dirname "$FEATURE_SPEC")
IMPL_PLAN="$FEATURE_DIR/plan.md"
if [[ ! -f "$IMPL_PLAN" ]]; then
  cp "$REPO_ROOT/.specify/templates/plan-template.md" "$IMPL_PLAN" 2>/dev/null || touch "$IMPL_PLAN"
fi
echo "Created plan: $IMPL_PLAN"
