Param()
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot){ $repoRoot=(Get-Location).Path }
$spec = Get-ChildItem -Path (Join-Path $repoRoot specs) -Recurse -Filter spec.md | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $spec){ Write-Error 'spec.md not found'; exit 1 }
$featureDir = Split-Path $spec.FullName -Parent
$plan = Join-Path $featureDir 'plan.md'
$template = Join-Path $repoRoot '.specify/templates/plan-template.md'
if (Test-Path $template){ Copy-Item $template $plan -Force } else { New-Item -ItemType File -Path $plan -Force | Out-Null }
Write-Output "Created plan: $plan"
