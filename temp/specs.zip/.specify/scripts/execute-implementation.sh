#!/usr/bin/env bash
set -e
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
FEATURE_DIR=$(ls -1dt "$REPO_ROOT/specs"/*/ 2>/dev/null | head -n1)
[[ -z "$FEATURE_DIR" ]] && { echo "Error: no feature directory" >&2; exit 1; }
TASKS="$FEATURE_DIR/tasks.md"
[[ ! -f "$TASKS" ]] && { echo "Error: tasks.md missing" >&2; exit 1; }
echo "(stub) Implementation would execute tasks in $TASKS"
