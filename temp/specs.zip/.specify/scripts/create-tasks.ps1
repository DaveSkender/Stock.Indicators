Param()
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot){ $repoRoot=(Get-Location).Path }
$featureDir = Get-ChildItem -Directory -Path (Join-Path $repoRoot specs) | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $featureDir){ Write-Error 'No feature directory'; exit 1 }
$tasks = Join-Path $featureDir.FullName 'tasks.md'
$template = Join-Path $repoRoot '.specify/templates/tasks-template.md'
if (Test-Path $template){ Copy-Item $template $tasks -Force } else { '# Tasks' | Out-File $tasks -Encoding utf8 }
Write-Output "Created tasks: $tasks"
