#!/usr/bin/env bash
set -e
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
FEATURE_DIR=$(ls -1dt "$REPO_ROOT/specs"/*/ 2>/dev/null | head -n1)
[[ -z "$FEATURE_DIR" ]] && { echo "Error: no feature directory" >&2; exit 1; }
PLAN="$FEATURE_DIR/plan.md"
SPEC="$FEATURE_DIR/spec.md"
[[ ! -f "$PLAN" || ! -f "$SPEC" ]] && { echo "Error: spec.md and plan.md required" >&2; exit 1; }
TASKS="$FEATURE_DIR/tasks.md"
cp "$REPO_ROOT/.specify/templates/tasks-template.md" "$TASKS" 2>/dev/null || cat > "$TASKS" <<EOF
# Tasks
EOF
echo "Created tasks: $TASKS"
