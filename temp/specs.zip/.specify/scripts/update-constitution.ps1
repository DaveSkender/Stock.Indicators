Param()
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot){ $repoRoot=(Get-Location).Path }
$con = Join-Path $repoRoot '.specify/memory/constitution.md'
if (-not (Test-Path $con)){ Write-Error 'constitution.md missing'; exit 1 }
Write-Output "(stub) Update process not automated; edit $con or extend script."
