#!/usr/bin/env bash
set -e
JSON_MODE=false
for arg in "$@"; do
  case "$arg" in
    --json) JSON_MODE=true ;;
  esac
done
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
FEATURE_SPEC=$(ls -1t "$REPO_ROOT/specs"/*/spec.md 2>/dev/null | head -n1)
[[ -z "$FEATURE_SPEC" ]] && { echo "Error: no spec.md found" >&2; exit 1; }
FEATURE_DIR=$(dirname "$FEATURE_SPEC")
IMPL_PLAN="$FEATURE_DIR/plan.md"
TEMPLATE="$REPO_ROOT/.specify/templates/plan-template.md"
[[ -f "$TEMPLATE" ]] && cp "$TEMPLATE" "$IMPL_PLAN" || touch "$IMPL_PLAN"
BRANCH="$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo main)"
if $JSON_MODE; then
  printf '{"FEATURE_SPEC":"%s","IMPL_PLAN":"%s","SPECS_DIR":"%s","BRANCH":"%s"}\n' "$FEATURE_SPEC" "$IMPL_PLAN" "$FEATURE_DIR" "$BRANCH"
else
  echo "FEATURE_SPEC: $FEATURE_SPEC"
  echo "IMPL_PLAN: $IMPL_PLAN"
  echo "SPECS_DIR: $FEATURE_DIR"
  echo "BRANCH: $BRANCH"
fi
