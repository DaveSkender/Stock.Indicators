#!/usr/bin/env bash
set -e

# Simplified create-new-feature script for Stock Indicators integration
# Outputs JSON with FEATURE_SPEC path, BRANCH_NAME

FEATURE_DESC="$*"
if [[ -z "$FEATURE_DESC" ]]; then
  echo "Error: feature description required" >&2
  exit 1
fi

REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
SPECS_DIR="$REPO_ROOT/specs"
mkdir -p "$SPECS_DIR"

NEXT_ID=$(find "$SPECS_DIR" -maxdepth 1 -name "[0-9][0-9][0-9]-*" | wc -l)
NEXT_ID=$((NEXT_ID + 1))
SPEC_ID=$(printf "%03d" "$NEXT_ID")
SLUG=$(echo "$FEATURE_DESC" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9 ]//g' | sed 's/  */ /g' | sed 's/ /-/g' | cut -c1-48)
DIR_NAME="$SPEC_ID-$SLUG"
FEATURE_DIR="$SPECS_DIR/$DIR_NAME"
mkdir -p "$FEATURE_DIR"

BRANCH_NAME="feat/spec-$DIR_NAME"

SPEC_FILE="$FEATURE_DIR/spec.md"
if [[ ! -f "$SPEC_FILE" ]]; then
  cat > "$SPEC_FILE" <<EOF
# Specification: $FEATURE_DESC

## Overview

$FEATURE_DESC

## Clarifications

*None yet*

---
Created: $(date -I)
Specification ID: $SPEC_ID
EOF
fi

cat <<JSON
{"BRANCH_NAME":"$BRANCH_NAME","FEATURE_SPEC":"$SPEC_FILE","FEATURE_DIR":"$FEATURE_DIR"}
JSON
