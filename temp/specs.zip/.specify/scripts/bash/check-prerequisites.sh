#!/usr/bin/env bash
set -e
JSON=false
INCLUDE_TASKS=false
REQUIRE_TASKS=false
for arg in "$@"; do
  case "$arg" in
    --json) JSON=true ;;
    --include-tasks) INCLUDE_TASKS=true ;;
    --require-tasks) REQUIRE_TASKS=true ;;
  esac
done
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
FEATURE_DIR=$(ls -1dt "$REPO_ROOT/specs"/*/ 2>/dev/null | head -n1)
[[ -z "$FEATURE_DIR" ]] && { echo "Error: no feature directory found" >&2; exit 1; }
FEATURE_SPEC="$FEATURE_DIR/spec.md"
IMPL_PLAN="$FEATURE_DIR/plan.md"
TASKS_FILE="$FEATURE_DIR/tasks.md"
AVAILABLE_DOCS=()
[[ -f "$FEATURE_SPEC" ]] && AVAILABLE_DOCS+=(spec.md)
[[ -f "$IMPL_PLAN" ]] && AVAILABLE_DOCS+=(plan.md)
if [[ -f "$TASKS_FILE" ]]; then AVAILABLE_DOCS+=(tasks.md); fi
if $REQUIRE_TASKS && [[ ! -f "$TASKS_FILE" ]]; then echo "Error: tasks.md required" >&2; exit 1; fi
if $JSON; then
  printf '{"FEATURE_DIR":"%s","AVAILABLE_DOCS":["%s"],"HAS_TASKS":%s}\n' "$FEATURE_DIR" "${AVAILABLE_DOCS[*]}" $([[ -f "$TASKS_FILE" ]] && echo true || echo false)
else
  echo "FEATURE_DIR: $FEATURE_DIR"
  echo "AVAILABLE_DOCS: ${AVAILABLE_DOCS[*]}"
fi
