#!/usr/bin/env bash
set -e
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_FILE="${REPO_ROOT}/.github/copilot-instructions.md"
TEMPLATE="${REPO_ROOT}/.specify/templates/agent-file-template.md"
DATE=$(date -I)
if [[ -f "$TEMPLATE" ]]; then
  CONTENT=$(sed "s/\[DATE\]/$DATE/" "$TEMPLATE")
  echo "$CONTENT" > "$AGENT_FILE"
  echo "Updated agent file: $AGENT_FILE"
else
  echo "Template missing: $TEMPLATE" >&2
fi
