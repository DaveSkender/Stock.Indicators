Param([switch]$Json,[switch]$RequireTasks,[switch]$IncludeTasks)
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot) { $repoRoot = (Get-Location).Path }
$featureDir = Get-ChildItem -Directory -Path (Join-Path $repoRoot specs) | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $featureDir) { Write-Error 'No feature directory found'; exit 1 }
$specFile = Join-Path $featureDir.FullName 'spec.md'
$planFile = Join-Path $featureDir.FullName 'plan.md'
$tasksFile = Join-Path $featureDir.FullName 'tasks.md'
$docs = @()
if (Test-Path $specFile) { $docs += 'spec.md' }
if (Test-Path $planFile) { $docs += 'plan.md' }
if (Test-Path $tasksFile) { $docs += 'tasks.md' }
if ($RequireTasks -and -not (Test-Path $tasksFile)) { Write-Error 'tasks.md required'; exit 1 }
if ($Json) { @{FEATURE_DIR=$featureDir.FullName;AVAILABLE_DOCS=$docs;HAS_TASKS=(Test-Path $tasksFile)} | ConvertTo-Json -Compress } else { Write-Output "FEATURE_DIR: $($featureDir.FullName)`nAVAILABLE_DOCS: $($docs -join ' ')" }
