Param([switch]$Json)
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot) { $repoRoot = (Get-Location).Path }
$spec = Get-ChildItem -Path (Join-Path $repoRoot specs) -Recurse -Filter spec.md | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $spec) { Write-Error 'No spec.md found'; exit 1 }
$featureSpec = $spec.FullName
$featureDir = Split-Path $featureSpec -Parent
$implPlan = Join-Path $featureDir 'plan.md'
$template = Join-Path $repoRoot '.specify/templates/plan-template.md'
if (Test-Path $template) { Copy-Item $template $implPlan -Force } else { New-Item -ItemType File -Path $implPlan -Force | Out-Null }
$branch = (git rev-parse --abbrev-ref HEAD) 2>$null; if (-not $branch) { $branch = 'main' }
if ($Json) { @{FEATURE_SPEC=$featureSpec;IMPL_PLAN=$implPlan;SPECS_DIR=$featureDir;BRANCH=$branch} | ConvertTo-Json -Compress } else { Write-Output "FEATURE_SPEC: $featureSpec`nIMPL_PLAN: $implPlan`nSPECS_DIR: $featureDir`nBRANCH: $branch" }
