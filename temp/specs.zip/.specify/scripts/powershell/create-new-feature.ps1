Param([Parameter(ValueFromRemainingArguments=$true)][string[]]$Args)
$feature = ($Args -join ' ').Trim()
if (-not $feature) { Write-Error 'Feature description required'; exit 1 }
$repoRoot = (git rev-parse --show-toplevel) 2>$null; if (-not $repoRoot) { $repoRoot = (Get-Location).Path }
$specs = Join-Path $repoRoot 'specs'
New-Item -ItemType Directory -Force -Path $specs | Out-Null
$next = (Get-ChildItem -Path $specs -Directory | Where-Object { $_.Name -match '^[0-9]{3}-' } | Measure-Object).Count + 1
$specId = '{0:000}' -f $next
$slug = ($feature.ToLower() -replace '[^a-z0-9 ]','' -replace ' +','-' )
$dirName = "$specId-$slug"
$featureDir = Join-Path $specs $dirName
New-Item -ItemType Directory -Force -Path $featureDir | Out-Null
$specFile = Join-Path $featureDir 'spec.md'
if (-not (Test-Path $specFile)) {
  @("# Specification: $feature","","## Overview","",$feature,"","## Clarifications","","*None yet*","","---","Created: $(Get-Date -Format yyyy-MM-dd)","Specification ID: $specId") | Set-Content $specFile
}
$branch = "feat/spec-$dirName"
Write-Output (@{BRANCH_NAME=$branch;FEATURE_SPEC=$specFile;FEATURE_DIR=$featureDir} | ConvertTo-Json -Compress)
