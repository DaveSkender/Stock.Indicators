# Implementation Tasks: StaticSeries Regression Baselines

Linked Spec: `specs/002-regression-baselines/spec.md`
Plan Reference: `plan.md`
Status: Draft
Created: 2025-10-02

## Legend

- [ ] Not Started
- [~] In Progress
- [x] Complete

## Phase 1: Generator & Binary Format

- [ ] T1.1 Create `TestDataGenerator` console project under `tools/TestDataGenerator`
- [ ] T1.2 Implement Catalog enumeration (Style.Series) with default parameter extraction
- [ ] T1.3 Implement reflection-based row normalizer (cache property delegates, exclude `Date`)
- [ ] T1.4 Implement binary writer (header + field table + rows + hash patch)
- [ ] T1.5 Implement SHA256 streaming hash for row segment
- [ ] T1.6 Implement CLI options (`--indicator`, `--list`, `--verbose`)
- [ ] T1.7 Implement invariant validations (monotonic timestamps, at least one non-null value, finite or NaN for nulls, unique field names)
- [ ] T1.8 Integrate git commit SHA capture (`git rev-parse HEAD` fallback `UNKNOWN`)

## Phase 2: Baseline Generation

- [ ] T2.1 Integrate shared Standard test quote dataset loader
- [ ] T2.2 Generate initial `.Standard.bin` baselines (subset: SMA, EMA) for validation
- [ ] T2.3 Verify binary integrity (hash recompute vs stored)
- [ ] T2.4 Expand to all StaticSeries indicators
- [ ] T2.5 Commit initial baseline set (PR: `test: add initial regression baselines`)

## Phase 3: Regression Tests (Co-located)

- [ ] T3.1 Add shared binary reader utility in test common folder
- [ ] T3.2 Add `[TestCategory("Regression")]` test to one indicator test file (Sma) to validate harness
- [ ] T3.3 Roll-out regression test to all indicator StaticSeries test files
- [ ] T3.4 Add Buffer/Stream style comparison tests referencing same baseline (where applicable)
- [ ] T3.5 Implement numeric tolerance + strict mode env flag
- [ ] T3.6 Implement diff aggregation (max 5 diffs/file)
- [ ] T3.7 Introduce failure categorization (STRUCTURE/LENGTH/ORDER/VALUE)

## Phase 4: CI & Documentation

- [ ] T4.1 Update `.vscode/tasks.json` test task filter to exclude Regression & Integration: `--filter "TestCategory!=Regression&TestCategory!=Integration"`
- [ ] T4.2 Ensure existing integration tests explicitly tagged `[TestCategory("Integration")]`
- [ ] T4.3 Add CONTRIBUTING note: baseline regeneration workflow
- [ ] T4.4 Add spec reference link in root README (optional)

## Phase 5: Quality & Hardening

- [ ] T5.1 Manual dry run with intentional perturbation to confirm failure message clarity
- [ ] T5.2 Confirm performance overhead acceptable (<5% time increase)
- [ ] T5.3 Add analyzer suppression file if needed (documentation only)
- [ ] T5.4 Final review & mark spec status -> In Progress

## Stretch (Deferred)

- [ ] S1 Add HighLow scenario support
- [ ] S2 Add StreamHub/BufferList baselines reuse
- [ ] S3 Add hash verification during tests (recompute + compare)
- [ ] S4 Add diff reporter with % change sorting
- [ ] S5 Add compression (e.g., LZ4) prototype for large future datasets

---
*This tasks list operationalizes the regression baseline system. Update statuses as work proceeds.*

---
Last updated: October 2, 2025
