# Feature Specification: StaticSeries Regression Baselines

**Feature Branch**: `plan-regression-tests`  
**Created**: 2025-10-02  
**Status**: Draft  
**Input**: User request: Establish deterministic regression baseline suite for all StaticSeries indicator Standard tests.

## Overview

Introduce a regression baseline system that persistently stores canonical output sequences for every StaticSeries indicator "Standard" scenario. The goal is to detect any unintended numerical, ordering, warmup, or schema changes introduced by refactors, performance optimizations, or algorithmic adjustments. Baselines are stored as compact binary files colocated with each indicator's existing test folder for fast load and minimal parsing overhead. Warmup (null) periods are preserved. Metadata is encoded in a lightweight header for reproducibility and integrity verification.

## Background

Current unit tests validate correctness via spot checks and tolerance-based assertions per indicator, but they do not guard comprehensively against subtle output drift across the full time series (e.g., rounding ripple effects, warmup alignment shifts, property omissions). Introducing full-series baselines creates a deterministic reference providing high-fidelity change detection. This supports safer refactors (e.g., loop unrolling, allocation reduction, streaming parity improvements) and enables confident evolution of numerical algorithms.

## User Scenarios & Testing

### Primary Use Cases

1. Refactor an indicator implementation → regression suite immediately flags any unintended shifts.
2. Add a new optimization (e.g., reduce allocations) → validate identical outputs pre/post.
3. Upgrade .NET runtime or compiler → detect precision or JIT-induced variance.
4. Add new indicator → baseline required; absence triggers failure.
5. Tighten warmup logic → verify only deliberate baseline changes are introduced.

### Success Scenarios

- Developer runs full test pipeline → regression suite passes with zero diffs.
- Intentional algorithm improvement → baseline diff surfaces; developer regenerates explicitly and commits rationale.
- CI blocks merge when drift occurs without approved regeneration.
- Filtered execution (single indicator) aids rapid debugging of a failing baseline.

## Functional Requirements

| ID | Requirement |
|----|-------------|
| FR1 | Persist a binary (.bin) baseline for each StaticSeries indicator Standard test scenario, stored beside its test files. |
| FR2 | Include full ordered dataset including warmup null periods. |
| FR3 | Provide deterministic serialization (stable property ordering, invariant culture for any textual elements). |
| FR4 | Provide a manual generator tool; not automatically executed in CI. |
| FR5 | Compute and store a cryptographic hash (SHA256) of the raw row segment (after header) for integrity. |
| FR6 | Regression tests must enumerate all baselines and compare recomputed outputs. |
| FR7 | Fail if any expected baseline file is missing or if unexpected files appear. |
| FR8 | Support numeric comparison with dual absolute (1e-10) and relative (1e-8) tolerances. |
| FR9 | Support strict mode (env `REGRESSION_STRICT=1`) → exact match required. |
| FR10 | Support filtering by indicator via env `REGRESSION_FILTER`. |
| FR11 | Fail with categorized error (STRUCTURE/LENGTH/ORDER/VALUE). |
| FR12 | Omit fields that are null for the entire dataset (size optimization). |
| FR13 | Ensure at least one non-null computed value exists or baseline generation fails. |
| FR14 | All timestamps serialized ISO-8601 UTC without fractional seconds. |
| FR15 | Binary header includes: magic bytes, version, field count, record count, ticks base flag, commit SHA (short), assembly version, generation UTC (ticks), SHA256 hash. |
| FR16 | Baseline schema changes tracked via schemaVersion integer. |

## Non-Functional Requirements

- Minimal additional repository size (<10MB target; expected <<1MB initially).
- Negligible added CI time (<5% test stage increase) due to efficient O(n) comparisons.
- Zero allocations beyond materializing indicator results + comparison objects (avoid LINQ in hot loops).
- Deterministic output independent of machine locale or timezone.

## Key Entities

- Baseline Binary File (per indicator, Data + Header)
- Test Data Generator Console App (`TestDataGenerator`)
- Regression Test Harness (dynamic enumeration)
- Indicator Registry (maps indicator name → factory/runner for Standard scenario)
- Serialization Normalizer (shapes result models into row dictionaries)

## Data Model

### Binary File Layout (Version 1)

All multi-byte integers little-endian.

```text
Offset  Size  Description
0       4     Magic 'SIGB' (Stock Indicators Baseline)
4       1     Version (1)
5       1     Field count (F) excluding timestamp
6       4     Record count (R)
10      8     Generation UTC ticks (Int64)
18      2     Commit SHA length (C) (ushort)
20      C     UTF8 commit SHA (short or full)
20+C    2     Assembly version length (A) (ushort)
22+C    A     UTF8 assembly version
22+C+A  32    SHA256 hash (first 32 bytes full digest) of row segment (after header end)
...            Field name table:
               For each field (F): 1 byte name length (N) + N bytes UTF8 name
...            Row segment begins (hash covers from here to EOF):
               For each row (R): 8 bytes DateTime ticks + (F * 8 bytes double) (use IEEE NaN to represent null)
```

Notes:

- Field order is alphabetical by property name.
- Dates stored as raw ticks for fast reconstruction.
- NaN signifies warmup/null result entry.
- No compression; typical file sizes remain small.


## File Naming Convention

`<Indicator>.Standard.bin` (PascalCase, matches existing indicator class base name) placed in the indicator's test directory (e.g., `tests/indicators/s-z/Sma/`).

Future variant example: `<Indicator>.StandardHighLow.bin`.

## Serialization Rules

1. Field order alphabetical (excluding timestamp which is implicit first element per row).
2. Omit properties whose value set is entirely null across all rows.
3. Warmup/null values stored as IEEE NaN.
4. Stable deterministic ordering of rows by ascending timestamp enforced.
5. Hash ensures tamper detection; mismatch triggers regeneration guidance.

## Tolerance & Comparison Algorithm

For each numeric field:

- Let expected = E, actual = A.
- Pass if |A - E| <= 1e-10 OR (|E| > 1e-6 AND |A - E| / |E| <= 1e-8).
- If strict mode active → require exact double equality (NaN parity allowed only if both NaN → considered null parity).


Mismatches are aggregated; up to first 5 per file recorded in failure message including: index, field, expected, actual, absDelta, relDelta.

## Generator Design

Console application responsibilities:

1. Enumerate StaticSeries indicators from `Catalog` (Style.Series) and derive default parameters.
2. Acquire shared test quotes dataset (same used by Standard tests).
3. Invoke each Standard scenario method with default parameters to produce results (reflection or curated mapping for phase 1).
4. Normalize each row (public get properties excluding `Date` plus indicator numeric outputs only).
5. Build field name table (filter out all-null fields).
6. Write header then rows streaming; compute SHA256 incrementally for row segment.
7. Flush file, then patch in final hash (write placeholder first or buffer rows before writing header hash region).
8. Validate invariants (monotonic timestamps, at least one non-null numeric field, finite numbers or NaN for nulls, property name uniqueness).
9. Overwrite existing baseline file.


CLI Options (initial):

- `--indicator <Name>` (optional subset for faster regeneration)
- `--list` (dry-run listing only)
- `--verbose` (extra diagnostics)


## Regression Test Flow

1. Locate baseline file `<Indicator>.Standard.bin` in the same folder as the indicator's StaticSeries test file.
2. If `REGRESSION_FILTER` set, only process matching indicator IDs.
3. Parse binary header; read field table and rows; reconstruct nullable doubles (treat NaN as null).
4. Recompute runtime output using default Catalog parameters.
5. Normalize runtime rows with identical field ordering and null handling.
6. Structural assertions:
   - Baseline file exists.
   - Row count matches.
   - Timestamp sequence matches.
   - Field set matches.
7. Numeric tolerance comparison per field per row.
8. Aggregate diffs (max 5) and fail at end if any mismatch categories present.

## Performance Considerations

- Row shaping avoids boxing by precomputing PropertyInfo accessors and caching delegates per type.
- Avoid LINQ in inner loops; use `for` loops over materialized lists.
- Hash computed only once at generation (comparison does not recompute except optionally for validation debug mode in strict future enhancements).
- Regression tests run after unit tests; expected marginal runtime addition (<200ms for ~40k rows typical). Performance tests not required for harness itself.

## Extensibility

Planned extensions (not in initial scope):

- Add StreamHub and BufferList baselines (reuse StaticSeries baseline for equality compare).
- Multi-scenario coverage (e.g., HighLow) via additional file naming (e.g., `.StandardHighLow.bin`).
- Introduce binary schema version 2 for compression or extended metadata block.
- Differential reporter producing % change ranking.


## Risks & Mitigation

| Risk | Mitigation |
|------|------------|
| Unintentional baseline acceptance | Manual generator only; CI gate prevents silent drift |
| Overly strict tolerance causing noise | Dual absolute/relative tolerance; strict mode opt-in |
| Hidden property addition slipping in | Property set comparison ensures detection |
| Locale / timezone influence | Force invariant culture, UTC timestamps |
| Baseline file corruption | SHA256 hash enables verification (optional future validation step) |
| Developer forgets baseline for new indicator | STRUCTURE failure listing missing expected file |

## Success Criteria

- All StaticSeries Standard indicators have colocated `.Standard.bin` baseline file committed.
- Regression test suite (category `Regression`) passes with zero diffs on clean build.
- Buffer/Stream styles compare against StaticSeries baseline for equivalence.
- Intentional changes require explicit regeneration + Conventional Commit referencing rationale.
- CI rejects PR introducing drift without updated baselines.

## Out of Scope (Initial)

- Streaming / Buffer / Chainor baselines.
- Performance snapshot comparisons.
- Multi-parameter variants beyond Standard scenario.
- Binary compression of baseline artifacts.

## Implementation Phases

1. Generator (binary writer) + Catalog enumeration + field normalization.
2. Initial baseline generation & commit (per-indicator colocated files).
3. Add regression tests inside existing indicator test files (`[TestCategory("Regression")]`).
4. Update existing integration tests to `[TestCategory("Integration")]`; adjust test tasks filter.
5. Documentation (CONTRIBUTING note + spec maintenance).

## Open Questions / Decisions

| Topic | Decision |
|-------|----------|
| Indicator ordering in registry | Alphabetical by indicator name |
| Include `Value` alias properties? | No; use underlying explicit properties only (reduces duplication) |
| Decimal vs double precision | Retain existing double approach consistent with library focus |
| Hash verification during tests | Deferred (metadata trust sufficient now) |
| JSON indentation | None (minified) |

---
*This specification defines the StaticSeries regression baseline system to guarantee deterministic, drift-detecting reference outputs for all Standard scenarios.*

---
Last updated: October 2, 2025
